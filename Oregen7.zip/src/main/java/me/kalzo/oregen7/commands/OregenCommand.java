package me.kalzo.oregen7.commands;

import me.kalzo.oregen7.Oregen7;
import me.kalzo.oregen7.handlers.MaterialHandler.OreTier;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class OregenCommand implements CommandExecutor, TabCompleter {

    private String color(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("oregen7.admin")) {
            sender.sendMessage(color("&cBạn không có quyền sử dụng lệnh này!"));
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("reload")) {
            Oregen7.getInstance().reloadConfig();
            Oregen7.getInstance().getMaterialHandler().loadTiers();
            sender.sendMessage(color("&8[&6Oregen7&8] &aĐã tải lại cấu hình thành công!"));
            return true;
        }

        if (args.length == 1 && args[0].equalsIgnoreCase("gui") && sender instanceof Player player) {
            openAdminGUI(player);
            return true;
        }

        sender.sendMessage(color("&8[&6Oregen7&8] &fPhiên bản: &a" + Oregen7.getInstance().getDescription().getVersion()));
        sender.sendMessage(color("&f- &e/oregen7 reload &7(Tải lại cấu hình)"));
        sender.sendMessage(color("&f- &e/oregen7 gui &7(Mở GUI xem tỷ lệ quặng)"));
        return true;
    }

    private void openAdminGUI(Player player) {
        Map<String, OreTier> tiers = Oregen7.getInstance().getMaterialHandler().getTiers();

        if (tiers.isEmpty()) {
            player.sendMessage(color("&cChưa có cấp độ quặng nào được cài đặt trong config.yml!"));
            return;
        }

        // TỐI ƯU HÓA: Khóa giới hạn 54 ô (Giới hạn vật lý của Minecraft)
        int calculatedSize = (int) Math.ceil(Math.min(tiers.size(), 54) / 9.0) * 9;
        int size = Math.max(9, calculatedSize);

        Inventory inv = Bukkit.createInventory(null, size, color("&8Quản lý Tỷ lệ Quặng"));

        int count = 0;
        for (OreTier tier : tiers.values()) {
            if (count >= 54) break; // Chỉ hiển thị tối đa 54 cấp độ

            ItemStack item = new ItemStack(Material.DIAMOND_PICKAXE);
            ItemMeta meta = item.getItemMeta();
            if (meta != null) {
                meta.setDisplayName(color(tier.getDisplayName()));
                List<String> lore = new ArrayList<>();
                lore.add(color("&7Quyền LuckPerms: &b" + tier.getPermission()));
                lore.add(color("&7---------"));

                double total = tier.getTotalWeight();
                for (Map.Entry<Material, Double> entry : tier.getRawChances().entrySet()) {
                    double percent = total > 0 ? (entry.getValue() / total) * 100.0 : 0.0;
                    lore.add(color("&f- &e" + entry.getKey().name() + "&f: &a" + String.format("%.2f", percent) + "%"));
                }
                meta.setLore(lore);
                item.setItemMeta(meta);
            }
            inv.addItem(item);
            count++;
        }
        player.openInventory(inv);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String label, String[] args) {
        if (sender.hasPermission("oregen7.admin") && args.length == 1) {
            return List.of("reload", "gui");
        }
        return List.of();
    }
}