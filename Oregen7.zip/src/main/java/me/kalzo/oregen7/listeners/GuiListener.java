package me.kalzo.oregen7.listeners;

import me.kalzo.oregen7.Oregen7;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class GuiListener implements Listener {

    // Tối ưu hóa: String hằng số để không tạo lại đối tượng mỗi khi kiểm tra
    private static final String GUI_TITLE = ChatColor.translateAlternateColorCodes('&', "&8Quản lý Tỷ lệ Quặng");

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (GUI_TITLE.equals(event.getView().getTitle())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (GUI_TITLE.equals(event.getView().getTitle())) {
            event.setCancelled(true);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerQuit(PlayerQuitEvent event) {
        // Dọn dẹp cache của người chơi khi họ rời server
        Oregen7.getInstance().getMaterialHandler().clearCache(event.getPlayer().getUniqueId());
    }
}