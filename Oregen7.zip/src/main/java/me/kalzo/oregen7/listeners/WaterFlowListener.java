package me.kalzo.oregen7.listeners;

import com.bgsoftware.superiorskyblock.api.SuperiorSkyblockAPI;
import com.bgsoftware.superiorskyblock.api.island.Island;
import com.bgsoftware.superiorskyblock.api.wrappers.SuperiorPlayer;
import me.kalzo.oregen7.Oregen7;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockFromToEvent;

import java.util.UUID;

public class WaterFlowListener implements Listener {
    private static final BlockFace[] FACES = {
            BlockFace.DOWN, BlockFace.UP, BlockFace.NORTH, BlockFace.SOUTH, BlockFace.EAST, BlockFace.WEST
    };

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onWaterFlow(BlockFromToEvent event) {
        Block source = event.getBlock();
        if (source.getType() != Material.WATER) return;

        Block toBlock = event.getToBlock();
        if (toBlock.getType() != Material.AIR && toBlock.getType() != Material.CAVE_AIR) return;

        boolean hasFence = false;
        for (BlockFace face : FACES) {
            if (toBlock.getRelative(face).getType().name().endsWith("_FENCE")) {
                hasFence = true;
                break;
            }
        }
        if (!hasFence) return;

        FileConfiguration config = Oregen7.getInstance().getConfig();
        if (!config.getStringList("allowed-worlds").contains(source.getWorld().getName())) return;

        event.setCancelled(true);

        Island island = SuperiorSkyblockAPI.getGrid().getIslandAt(toBlock.getLocation());
        if (island == null) return;

        // TỐI ƯU HÓA: Quét thủ công an toàn nhất
        double radius = config.getDouble("scan-radius", 10.0);
        double radiusSquared = radius * radius;
        UUID targetUUID = null;
        Location toLoc = toBlock.getLocation();

        for (Player p : toLoc.getWorld().getPlayers()) {
            if (p.getLocation().distanceSquared(toLoc) <= radiusSquared) {
                SuperiorPlayer sp = SuperiorSkyblockAPI.getPlayer(p);
                if (sp != null && (island.equals(sp.getIsland()) || island.getCoopPlayers().contains(sp))) {
                    targetUUID = p.getUniqueId();
                    break;
                }
            }
        }

        Material oreToSpawn = Oregen7.getInstance().getMaterialHandler().getRandomOre(targetUUID);
        toBlock.setType(oreToSpawn);

        if (config.getBoolean("effects.enable-sound", true) || config.getBoolean("effects.enable-particle", true)) {
            triggerEffects(toBlock.getLocation(), oreToSpawn);
        }
    }

    private void triggerEffects(Location loc, Material mat) {
        World world = loc.getWorld();
        if (world == null) return;
        Location center = loc.add(0.5, 0.5, 0.5);
        boolean isRare = mat.name().contains("DIAMOND") || mat.name().contains("EMERALD") || mat.name().contains("GOLD");

        if (Oregen7.getInstance().getConfig().getBoolean("effects.enable-sound", true)) {
            world.playSound(center, Sound.BLOCK_LAVA_EXTINGUISH, 0.2f, 1.5f);
            if (isRare) world.playSound(center, Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 0.5f, 1.0f);
        }

        if (Oregen7.getInstance().getConfig().getBoolean("effects.enable-particle", true)) {
            world.spawnParticle(isRare ? Particle.HAPPY_VILLAGER : Particle.SMOKE, center, 3, 0.1, 0.1, 0.1, 0.05);
        }
    }
}