package me.kalzo.oregen7;

import net.luckperms.api.LuckPerms;
import net.luckperms.api.LuckPermsProvider;
import net.luckperms.api.event.EventBus;
import net.luckperms.api.event.user.UserDataRecalculateEvent;
import me.kalzo.oregen7.commands.OregenCommand;
import me.kalzo.oregen7.handlers.MaterialHandler;
import me.kalzo.oregen7.listeners.GuiListener;
import me.kalzo.oregen7.listeners.WaterFlowListener;
import org.bukkit.ChatColor;
import org.bukkit.plugin.java.JavaPlugin;

public final class Oregen7 extends JavaPlugin {
    private static Oregen7 instance;
    private MaterialHandler materialHandler;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        materialHandler = new MaterialHandler();
        materialHandler.loadTiers();

        getCommand("oregen7").setExecutor(new OregenCommand());

        getServer().getPluginManager().registerEvents(new WaterFlowListener(), this);
        getServer().getPluginManager().registerEvents(new GuiListener(), this);

        try {
            LuckPerms api = LuckPermsProvider.get();
            EventBus eventBus = api.getEventBus();
            eventBus.subscribe(this, UserDataRecalculateEvent.class, e -> {
                materialHandler.clearCache(e.getUser().getUniqueId());
            });
        } catch (Exception ignored) {}

        getServer().getConsoleSender().sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8[&6Oregen7&8] &aĐã khởi chạy thành công bởi Kalzo!"));
    }

    @Override
    public void onDisable() {
        // Tối ưu hóa: Dọn dẹp cache khi tắt plugin để tránh lỗi reload
        if (materialHandler != null) {
            materialHandler.loadTiers(); // Reset trạng thái
        }
    }

    public static Oregen7 getInstance() {
        return instance;
    }

    public MaterialHandler getMaterialHandler() {
        return materialHandler;
    }
}