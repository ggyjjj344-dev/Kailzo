package me.kalzo.oregen7.handlers;

import me.kalzo.oregen7.Oregen7;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ThreadLocalRandom;

public class MaterialHandler {
    private final Map<String, OreTier> tiers = new LinkedHashMap<>();
    private final Map<UUID, OreTier> playerCache = new ConcurrentHashMap<>();

    public void loadTiers() {
        tiers.clear();
        playerCache.clear();
        ConfigurationSection section = Oregen7.getInstance().getConfig().getConfigurationSection("tiers");
        if (section == null) return;

        for (String key : section.getKeys(false)) {
            String perm = section.getString(key + ".permission", "quyen.mac.dinh." + key);
            String name = section.getString(key + ".display-name", "&fMỏ Cấp " + key);
            OreTier tier = new OreTier(key, perm, name);

            ConfigurationSection chances = section.getConfigurationSection(key + ".chances");
            if (chances != null) {
                for (String matStr : chances.getKeys(false)) {
                    Material mat = Material.matchMaterial(matStr.toUpperCase());
                    if (mat != null) tier.addOre(mat, chances.getDouble(matStr));
                }
            }
            tiers.put(perm, tier);
        }
    }

    public Material getRandomOre(UUID playerUUID) {
        if (playerUUID == null) return getDefaultTier().nextOre();

        // Tối ưu hóa: Tránh truy vấn Database, chỉ dùng cache cho người chơi đang online
        return playerCache.computeIfAbsent(playerUUID, uuid -> {
            Player p = Bukkit.getPlayer(uuid);
            if (p == null) return getDefaultTier();

            List<OreTier> list = new ArrayList<>(tiers.values());
            // Duyệt ngược để tìm quyền cao nhất nhanh nhất
            for (int i = list.size() - 1; i >= 0; i--) {
                if (p.hasPermission(list.get(i).getPermission())) return list.get(i);
            }
            return getDefaultTier();
        }).nextOre();
    }

    public OreTier getDefaultTier() {
        if (tiers.isEmpty()) {
            OreTier fallback = new OreTier("fallback", "quyen.du.phong", "&fMỏ Dự Phòng");
            fallback.addOre(Material.COBBLESTONE, 100.0);
            return fallback;
        }
        return tiers.values().iterator().next();
    }

    public Map<String, OreTier> getTiers() { return tiers; }
    public void clearCache(UUID uuid) { playerCache.remove(uuid); }

    public static class OreTier {
        private final String id, permission, displayName;
        private final NavigableMap<Double, Material> map = new TreeMap<>();
        private double total = 0;

        public OreTier(String id, String permission, String displayName) {
            this.id = id; this.permission = permission; this.displayName = displayName;
        }

        public void addOre(Material mat, double weight) {
            if (weight <= 0) return;
            total += weight; map.put(total, mat);
        }

        public Material nextOre() {
            if (map.isEmpty()) return Material.COBBLESTONE;
            return map.higherEntry(ThreadLocalRandom.current().nextDouble() * total).getValue();
        }

        public String getDisplayName() { return displayName; }
        public String getPermission() { return permission; }
        public double getTotalWeight() { return total; }

        public Map<Material, Double> getRawChances() {
            Map<Material, Double> chances = new HashMap<>();
            double previous = 0;
            for (Map.Entry<Double, Material> entry : map.entrySet()) {
                chances.put(entry.getValue(), entry.getKey() - previous);
                previous = entry.getKey();
            }
            return chances;
        }
    }
}